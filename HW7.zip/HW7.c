//MelinaMarandi 
//40223074
#include<stdio.h>
#include<string.h>
#include<ctype.h>
int main()
{
    
    int n;
    printf("Enter a number for languages");
    scanf("%d",&n);

    
    char word1[n+1][25] ,word2[n+1][25];
    char phrase[n+1][25];
    word1[n][25]=0;
    word2[n][25]=0;
    phrase[n][25]=0;


    for (int i=0;i<n;i++)
    {  
        printf("Enter a words in language\n");
        scanf("%s  %s", (word1[i]),  (word2[i]));

    }
    for (int i=0;i<n;i++)
    {
        printf("%s  %s\n",(word1[i]),    (word2[i]));
    }

    printf("Enter a pharase which is made by the words1\n");
     
     for (int i=0;i<n;i++) 
      {
     
     scanf("%s",phrase[i]);
      }
     for( int i=0;i<n;i++)
      {
    for( int j=0;j<strlen (phrase[i]);j++)
        putchar(tolower(phrase[i][j]));
        printf("\t");
        
      }
      printf("\n");
      
    

      for (int i=0;i<n;i++)
      {
        
        if(strlen(word1[i])<=strlen(word2[i]))
        {
            for(int j=0;j<25;j++)
            {
                phrase[i][j]=word1[i][j];
            }
        }
        else 
        {
            for(int j=0;j<25;j++)
            {
                phrase[i][j]=word2[i][j];
            }
        }
      }
      printf("The final answer is\n");
      for(int j=0;j<n;j++)
      printf("%s\t",phrase[j]);
}


    

